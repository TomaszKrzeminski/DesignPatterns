**August 2016**
Moved to GitHub: https://github.com/jkhines/hfpatternsincsharp

**Project Description**
Now at GitHub. This project consists of ported code examples from the book Head First Design Patterns by Eric and Elizabeth Freeman into C#.

All example projects have been converted to use [Visual Studio 2010](http://www.microsoft.com/express/Downloads/#2010-Visual-CS) and target the [.NET Framework 4 Client Profile](http://msdn.microsoft.com/en-us/library/cc656912.aspx).

+Head First Design Patterns - Code Examples in C#+ in currently in pre-alpha.  Please view the [Issue Tracker](http://hfpatternsincsharp.codeplex.com/workitem/list/basic) for a list of open issues. 

**Project Milestones**
_Alpha_
* Convert the Composite and State example projects from Java to C#
_Beta_
* Add the Head First implementation of the Model-View-Controller pattern.
_Production_
* Confirm that all projects, especially the application harnesses, conform to the code in the book.
* Close all open work items.

The source is not verbatim from the book, rather it prefers C# syntax and data structures when applicable.
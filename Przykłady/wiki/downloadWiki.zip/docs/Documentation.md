**Head First Design Patterns Home**
[http://headfirstlabs.com/books/hfdp/](http://headfirstlabs.com/books/hfdp/)

The book and its associated downloads, such as the Java source code, can be found at the link above.  

The book was published in 2004, ten years after the "Gang of Four" book.  
[http://www.amazon.com/Design-Patterns-Elements-Reusable-Object-Oriented/dp/0201633612/](http://www.amazon.com/Design-Patterns-Elements-Reusable-Object-Oriented/dp/0201633612/)